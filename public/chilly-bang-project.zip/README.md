# Chilly Bang — Digital Label & QR Code Studio

Official web application and QR Code generation studio for **Chilly Bang — Homemade Chillie by OG** (260ml jars).

## 🚀 Quick & Simple Vercel Deployment

Deploy this project to Vercel in less than 1 minute to get your live URL:

### Option A: Push to GitHub & Connect Vercel (Recommended)
1. Initialize git and commit:
   ```bash
   git init
   git add .
   git commit -m "Deploy Chilly Bang Digital Label"
   ```
2. Create and push to a new GitHub repository:
   ```bash
   gh repo create chilly-bang --public --source=. --push
   ```
3. Go to [vercel.com/new](https://vercel.com/new), select your `chilly-bang` repository, and click **Deploy**.
   - *Framework Preset:* **Vite** (Vercel automatically detects this)
   - *Build Command:* `npm run build`
   - *Output Directory:* `dist`
4. Once deployed, Vercel gives you your live URL (e.g. `https://chilly-bang.vercel.app`).

### Option B: Deploy with Vercel CLI
```bash
npx vercel
```
Follow the prompts and accept the default settings.

---

## 🏷️ How to Make the QR Code for Your Link

1. Open this app in your browser (or visit your new Vercel URL).
2. Go to the **QR Studio** tab.
3. Enter your live Vercel URL in the **Live Destination URL** box (e.g. `https://chilly-bang.vercel.app`).
4. Choose your color palette (Jar Cream, Pure Monochrome, Dark Gold, or Spicy Red).
5. Click **Download PNG (High-Res)** or **Vector SVG**.
6. Or switch to **Jar Lid Print** to print a 12-sticker sheet of 45mm/55mm/65mm round lid labels directly to any standard printer!

---

## 📱 Features

- **Exact Digital Label**: Matches the original Chilly Bang label layout, fonts, colors, badge, specifications, numbered ingredients, allergen callout, and WhatsApp order button (+27 79 518 4779).
- **Dynamic QR Code**: The QR code on the digital label automatically encodes the live URL.
- **Printable Jar Lid Templates**: 45mm, 55mm, and 65mm round stickers with cut guides.
- **Instant Standalone HTML Export**: Download a single self-contained `.html` file with the embedded badge and dynamic QR code.
